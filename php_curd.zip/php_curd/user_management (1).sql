-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 13, 2021 at 11:13 AM
-- Server version: 5.7.33
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `name_1` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_2` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_no` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_1` varchar(156) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` tinyint(32) NOT NULL,
  `gender` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name_1`, `name_2`, `phone_no`, `email`, `password_1`, `age`, `gender`, `url`) VALUES
(1, 'suman', 'ddsa', '786674      ', 'sup4riya@gaml.com', '1234', 60, 'female       ', ''),
(7, 'ghgf', 'fgt        ', '9099898', 'sup4r@gmail.com', '7878', 60, 'female', ''),
(12, 'vsdddffs', 'jfhjggss', '786674      ', 'cgghhsjknn@gmail.com', '38f629170ac3ab74b9d6d2cc411c2f3c', 60, 'female       ', ''),
(13, 'dsdaaa', 'uihgg', '786674      ', 'gfhfag@gmail.com', 'b66dc44cd9882859d84670604ae276e6', 60, 'female       ', ''),
(14, 'shreya', 'chatterjee', '786674      ', 'shreyach24@gmail.com', '38f629170ac3ab74b9d6d2cc411c2f3c', 60, 'female       ', ''),
(15, 'tyyy', 'hii  ', '43343', 'sgjghg@gmail.com', '38f629170ac3ab74b9d6d2cc411c2f3c', 80, 'male', 'https://www.linkedin.com/in/supriya-chowdhury-17b453193'),
(16, 'geer', 'uiii', '4322', 'shshsjsdd@gmail.com', '38f629170ac3ab74b9d6d2cc411c2f3c', 78, 'female', 'https://www.linkedin.com/in/supriya-chowdhury-17b453193');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
